const clients = require('./clients');

module.exports = {
  ...clients,
};
