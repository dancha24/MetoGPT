const checkAdmin = require('./admin');

module.exports = {
  checkAdmin,
};
