const addTitle = require('./title');
const buildOptions = require('./build');
const initializeClient = require('./initalize');

module.exports = {
  addTitle,
  buildOptions,
  initializeClient,
};
